package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	
	private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDao);
	}
	
	
	@Before
	public void setUpTestMockData() {
		Associate associate1=new Associate(101, 78000,"harsimran","singh","training","analyst","fdtt456762","hsbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(12345,"hdfc","23456"));
		
		Associate associate2=new Associate(102, 78000,"harsimran","singh bedi","training","analyst","fdtt456762","hbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(65477,"hdfc","8488"));
		
		Associate associate3=new Associate(105, 78000,"harman","singh bedi","training","analyst","fdtt456762","hsbbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(65477,"hdfc","8488"));
		
		ArrayList<Associate> associatesList=new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);
		
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		
		
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associatesList);
		EasyMock.replay(mockAssociateDao);
		
	}
		@Test(expected=AssociateDetailsNotFoundException.class)
			public void testGetAssociateDataForInvalidAssociateId() throws AssociateDetailsNotFoundException{
			
			payrollServices.getAssociateDetails(1234);
			EasyMock.verify(mockAssociateDao.findOne(1234));
				
			}
		
		@Test
		public void testGetAssociateDataForValidAssociateId() throws AssociateDetailsNotFoundException
		{
			Associate expectedAssociate=new Associate(101, 78000,"harsimran","singh bedi","training","analyst","fdtt456762","hbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(65477,"hdfc","8488"));
		
			Associate actualAssociate=payrollServices.getAssociateDetails(101);
			assertEquals(expectedAssociate,actualAssociate);
			EasyMock.verify(mockAssociateDao.findOne(1234));
		
		}
		
		@After
		public void tearDownTestMockData() throws Exception
		{
			EasyMock.resetToDefault(mockAssociateDao);
			
		}
		
		@AfterClass
		public void tearDownTestEnv()
		{
			payrollServices=null;
			mockAssociateDao=null;
			
		}
		
		
			
		
	

}
