package com.cg.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;



public class PayrollServicesTest {
	
	private static PayrollServices services;

	
	@BeforeClass
	public static void setUpTestEnv()
	{
		services=new PayrollServicesImpl();
	}
	
	@Before
	public void  setUpTestData()
	{
		Associate associate1=new Associate(101, 78000,"harsimran","singh","training","analyst","fdtt456762","hsbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(12345,"hdfc","23456"));
		
		Associate associate2=new Associate(102, 78000,"harsimran","singh bedi","training","analyst","fdtt456762","hbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(65477,"hdfc","8488"));
	
	
		PayrollDBUtil.associates.put(associate1.getAssociateId(),associate1);
		PayrollDBUtil.associates.put(associate2.getAssociateId(),associate2);
		
		PayrollDBUtil.ASSOCIATE_ID_COUNTER=102;
	
	
	}
	
	@After
	public void tearDownTestData()
	{
		PayrollDBUtil.associates.clear();
		
	}
	@AfterClass
	public static void tearDownTestEnv()
	{
		services=null;
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDetailsForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		
	services.getAssociateDetails(12343);	
	
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
			public void testGetAssociateDetailsForValidAssociateId() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(102, 78000,"harsimran","singh bedi","training","analyst","fdtt456762","hbgmail.com" ,new Salary(35000,1800,1800), new BankDetails(65477,"hdfc","8488"));
		Associate actualAssociate=services.getAssociateDetails(102);
			services.getAssociateDetails(12343);	
			Assert.assertEquals(expectedAssociate,actualAssociate);
			
			}
	/*@Test
	public void testAcceptAssociateDetailsForInvalidData() throws AssociateDetailsNotFoundException{
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("harsimran", "SinghBedi", "hbhbgmail.com", "ytp", "coin", "hfd5666", 6745, 64343, 6577, 7577, 6732, "hdfc", "86486gg");

	Assert.assertEquals(expectedId,actualId);
	
	}
	*/
	@Test
	public void testAcceptAssociateDetailsForValidData() throws AssociateDetailsNotFoundException{
		int expectedId=103;
		int actualId=services.acceptAssociateDetails("harsimran", "SinghBedi", "hbhbgmail.com", "ytp", "coin", "hfd5666", 6745, 64343, 6577, 7577, 6732, "hdfc", "86486gg");

	Assert.assertEquals(expectedId,actualId);
	
	}
	
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalculateNetSalaryForInvalidAssociateId() throws AssociateDetailsNotFoundException{
		services.calculateNetSalary(1434);
	}
	
	@Test
	public void testCalculateNetSalaryForValidAssociateId() throws AssociateDetailsNotFoundException{
		int expectedNetSalary=0;
		int actualNetSalary=services.calculateNetSalary(102
				);
		Assert.assertEquals(expectedNetSalary,actualNetSalary);
	}
	
	

}
