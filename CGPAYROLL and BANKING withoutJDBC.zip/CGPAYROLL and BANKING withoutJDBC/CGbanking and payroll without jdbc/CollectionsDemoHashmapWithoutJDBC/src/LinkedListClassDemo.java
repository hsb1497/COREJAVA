
public class LinkedListClassDemo {
	import java.util.ArrayList;
	import java.util.Collections;

	public class ListClassesDemo {
		
		public static void LinkedListClassDemo()
		{
			LinkedList<String>strList=new LinkedList<>();   //Jdk7 feature 
			                                                                                 //jdk5 feature is ArrayList<String>strList=new ArrayList<String>()
			
			//insert
			
			strList.add("Satish");
			strList.add("Kumar");
			strList.add("Nilesh");
			strList.add("Rakesh");
			strList.add("Ayush");
			strList.add("Satish");
			strList.add("Mayur");
			
			System.out.println(strList);
			
			//search
			
			String nameToBeSearch="Ayush";
			
			System.out.println(strList.contains(nameToBeSearch));
			
			String nameToBeRemove="Rakesh";
			System.out.println(strList.remove(nameToBeRemove));
			
			for(String arrayList:strList)
			{
				System.out.println(arrayList);
			}
		
			
			ArrayList<Associate> associates=new ArrayList<>();
			
			
			//sorting
			Collections.sort(associates);
			for(Associate associate :associates)
			{
				System.out.println(associate);
				
			}
			
			System.out.println("====================================");
			Collections.sort(associates,new AssociateComparator());
			
			for(Associate associate:associates)
			{
				System.out.println(associate);
			}
			
		}

	}

}
