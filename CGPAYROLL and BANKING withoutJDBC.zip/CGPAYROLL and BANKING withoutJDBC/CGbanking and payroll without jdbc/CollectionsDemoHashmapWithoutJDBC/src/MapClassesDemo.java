import java.util.Set;
import java.util.Hashtable;

import com.cg.project.collections.ArrayList;
import com.cg.project.collections.Associate;
import com.cg.project.collections.Set;

public class MapClassesDemo {

	public void fun() {
		
		HashSet<Integer,Associate>associates=new HashSet<Integer,Associate>();  
		//insert

		associates.add(new Associate (111,"Satish","Mahajan",15000);
		associates.add(new Associate (112,"Kumar","Mahajan",45673));
		associates.add(new Associate (113,"Rajan","Mahajan",36271));
		associates.add(new Associate (114,"Rakesh","Mahajan",10002));
		associates.add(new Associate (115,"Ayush","Mahajan",15627));
		associates.add(new Associate (116,"Satish","Mahajan",15363));
		associates.add(new Associate (117,"Karan","Mahajan",74632));

		Associate associate =associates.get(112);
		Set<Integer> keys=associates.keySet();

		for(Integer key:keys) {
			System.out.println(associates.get(key));
		}

		ArrayList <Associate> associateList=new ArrayList<>(associateValues());

			}

		}


	


